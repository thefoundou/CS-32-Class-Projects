#ifndef PLAYER_H
#define PLAYER_H

//#include "Game.h"
#include <string>

using namespace std;

class Arena;
class Game;

class Player
{
public:
	// Constructor
	Player(Arena* ap, int r, int c);

	// Accessors
	int  row() const;
	int  col() const;
	bool isDead() const;

	// Mutators
	string dropPoisonVial();
	string move(int dir);
	void   setDead();

private:
	Arena* m_arena;
	int    m_row;
	int    m_col;
	bool   m_dead;
};

#endif // !PLAYER_H